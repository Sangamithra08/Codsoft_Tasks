# CODSOFT
Titanic Survival Prediction Data Science Project 

This project focuses on predicting the survival of passengers aboard the Titanic using machine learning techniques.
